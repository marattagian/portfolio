# 📋 URLs de Cloudinary - Template

## Instrucciones
1. Reemplaza `YOUR_CLOUD_NAME` con tu cloud name real
2. Reemplaza los Public IDs si usaste nombres diferentes
3. Copia y pega estas URLs en tus archivos

---

## 🎬 HERO VIDEO (index.html)

### Poster/Thumbnail
```html
poster="https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/so_0.0,q_auto,f_jpg,w_1920/portfolio/hero-video.jpg"
```

### Desktop - WebM (mejor compresión)
```html
<source 
    media="(min-width: 769px)" 
    src="https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:good,f_webm,w_1920,h_1080,c_fill,g_auto/portfolio/hero-video.webm" 
    type="video/webm" 
/>
```

### Desktop - MP4 (fallback)
```html
<source 
    media="(min-width: 769px)" 
    src="https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:good,f_mp4,w_1920,h_1080,c_fill,g_auto/portfolio/hero-video.mp4" 
    type="video/mp4" 
/>
```

### Mobile - WebM (optimizado)
```html
<source 
    media="(max-width: 768px)" 
    src="https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:low,f_webm,w_1280,h_720,c_fill,g_auto/portfolio/hero-video.webm" 
    type="video/webm" 
/>
```

### Mobile - MP4 (fallback)
```html
<source 
    media="(max-width: 768px)" 
    src="https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:low,f_mp4,w_1280,h_720,c_fill,g_auto/portfolio/hero-video.mp4" 
    type="video/mp4" 
/>
```

---

## 📊 PROYECTOS (projects-data.js)

### Configuración Base
```javascript
const CLOUDINARY_CLOUD_NAME = 'YOUR_CLOUD_NAME'; // ⚠️ CAMBIAR
const CLOUDINARY_BASE_URL = `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}`;
```

### Helper Function
```javascript
function getCloudinaryURL(publicId, options = {}) {
  const {
    format = 'auto',
    quality = 'auto',
    width = null,
    height = null,
  } = options;
  
  let transformations = `q_${quality},f_${format}`;
  
  if (width) transformations += `,w_${width}`;
  if (height) transformations += `,h_${height}`;
  
  return `${CLOUDINARY_BASE_URL}/video/upload/${transformations}/${publicId}`;
}
```

### Proyecto 1: Boda
```javascript
{
  title: "Nadia & Nacho",
  role: "Filmmaker / Editor / Colorista",
  
  // Imagen estática (poster)
  staticImage: "https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/so_0.0,q_auto,f_jpg,w_800/portfolio/boda-loop.jpg",
  
  // Preview animado
  animatedPreview: "https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:low,f_webm,w_800,h_600/portfolio/boda-loop.webm",
  
  videoID: "qFdSlvkQ-CM",
  platform: "youtube",
}
```

### Proyecto 2: Dron
```javascript
{
  title: "Real State",
  role: "Piloto de Dron / Editor",
  
  staticImage: "https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/so_0.0,q_auto,f_jpg,w_800/portfolio/dron-loop.jpg",
  
  animatedPreview: "https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:low,f_webm,w_800,h_600/portfolio/dron-loop.webm",
  
  videoID: "1161221236",
  platform: "vimeo",
}
```

### Proyecto 3: Fuesmen
```javascript
{
  title: "Fuesmen",
  role: "Filmmaker / Editor",
  
  staticImage: "https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/so_0.0,q_auto,f_jpg,w_800/portfolio/fuesmen-loop.jpg",
  
  animatedPreview: "https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:low,f_webm,w_800,h_600/portfolio/fuesmen-loop.webm",
  
  videoID: "PcBxHz0ozxM",
  platform: "youtube",
}
```

---

## 🔍 Verificar URLs

### Test en Navegador
Abre estas URLs en tu navegador para verificar que funcionan:

```
https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/portfolio/hero-video.mp4

https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/portfolio/boda-loop.webm

https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/portfolio/dron-loop.webm

https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/portfolio/fuesmen-loop.webm
```

Si alguna da error 404:
- Verifica que el video esté subido
- Verifica que el Public ID sea correcto
- Verifica que tu Cloud Name sea correcto

---

## 📝 Ejemplo Completo con Cloud Name

Si tu Cloud Name es `democloud`:

### Hero Video
```html
<video 
    id="hero-video"
    autoplay 
    muted 
    loop 
    playsinline
    preload="auto"
    poster="https://res.cloudinary.com/democloud/video/upload/so_0.0,q_auto,f_jpg,w_1920/portfolio/hero-video.jpg"
>
    <source 
        media="(min-width: 769px)" 
        src="https://res.cloudinary.com/democloud/video/upload/q_auto:good,f_webm,w_1920,h_1080,c_fill,g_auto/portfolio/hero-video.webm" 
        type="video/webm" 
    />
    <source 
        media="(min-width: 769px)" 
        src="https://res.cloudinary.com/democloud/video/upload/q_auto:good,f_mp4,w_1920,h_1080,c_fill,g_auto/portfolio/hero-video.mp4" 
        type="video/mp4" 
    />
    <source 
        media="(max-width: 768px)" 
        src="https://res.cloudinary.com/democloud/video/upload/q_auto:low,f_webm,w_1280,h_720,c_fill,g_auto/portfolio/hero-video.webm" 
        type="video/webm" 
    />
    <source 
        media="(max-width: 768px)" 
        src="https://res.cloudinary.com/democloud/video/upload/q_auto:low,f_mp4,w_1280,h_720,c_fill,g_auto/portfolio/hero-video.mp4" 
        type="video/mp4" 
    />
</video>
```

### Projects Data
```javascript
const CLOUDINARY_CLOUD_NAME = 'democloud';
const CLOUDINARY_BASE_URL = `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}`;
```

---

## 🎯 Transformaciones Explicadas

### Parámetros

| Código | Significado | Valores |
|--------|-------------|---------|
| `q_auto` | Calidad automática | `auto`, `auto:good`, `auto:low` |
| `f_auto` | Formato automático | `auto`, `webm`, `mp4`, `jpg` |
| `w_` | Ancho (width) | `1920`, `1280`, `800` |
| `h_` | Alto (height) | `1080`, `720`, `600` |
| `c_fill` | Crop para llenar | `fill`, `scale`, `fit` |
| `g_auto` | Gravedad | `auto`, `center`, `face` |
| `so_` | Seek offset (timestamp) | `0.0` = inicio |

### Ejemplos de Uso

**Alta calidad, formato automático:**
```
q_auto:good,f_auto,w_1920,h_1080
```

**Baja calidad, WebM específico:**
```
q_auto:low,f_webm,w_800
```

**Thumbnail del segundo 0:**
```
so_0.0,q_auto,f_jpg,w_1920
```

---

## ✅ Checklist de Reemplazo

### En index.html:
- [ ] Línea ~81: poster URL
- [ ] Línea ~86: Desktop WebM
- [ ] Línea ~92: Desktop MP4
- [ ] Línea ~98: Mobile WebM
- [ ] Línea ~104: Mobile MP4

### En js/projects-data.js:
- [ ] Línea 11: CLOUDINARY_CLOUD_NAME
- [ ] Proyecto Boda: staticImage
- [ ] Proyecto Boda: animatedPreview
- [ ] Proyecto Dron: staticImage
- [ ] Proyecto Dron: animatedPreview
- [ ] Proyecto Fuesmen: staticImage
- [ ] Proyecto Fuesmen: animatedPreview

Total: **12 reemplazos de YOUR_CLOUD_NAME**

---

## 🔗 Links Útiles

- **Cloudinary Dashboard:** https://cloudinary.com/console
- **Media Library:** https://cloudinary.com/console/media_library
- **Transformation Reference:** https://cloudinary.com/documentation/image_transformation_reference
- **Video Transformations:** https://cloudinary.com/documentation/video_manipulation_and_delivery

---

## 💡 Tips

1. **Siempre usa `f_auto`** - Cloudinary servirá el formato óptimo
2. **`q_auto` es inteligente** - Ajusta la calidad según el contexto
3. **Mobile = `q_auto:low`** - Ahorra datos móviles
4. **Desktop = `q_auto:good`** - Mejor calidad en pantallas grandes
5. **Posters con `so_0.0`** - Extrae frame del inicio del video
