# 🎬 Guía de Configuración de Cloudinary - Portfolio

## 📋 Índice
1. [Configuración Inicial de Cloudinary](#1-configuración-inicial-de-cloudinary)
2. [Subir Videos a Cloudinary](#2-subir-videos-a-cloudinary)
3. [Configurar el Portfolio](#3-configurar-el-portfolio)
4. [Testing](#4-testing)
5. [Troubleshooting](#5-troubleshooting)

---

## 1. Configuración Inicial de Cloudinary

### Paso 1: Crear Cuenta (si no tienes una)

1. Ve a [cloudinary.com](https://cloudinary.com)
2. Haz clic en "Sign Up" (es gratis hasta 25GB/mes)
3. Completa el registro

### Paso 2: Obtener tu Cloud Name

1. Una vez registrado, ve al **Dashboard**
2. En la esquina superior izquierda verás tu **Cloud name**
3. Cópialo (lo necesitarás después)

Ejemplo: Si tu Cloud name es `democloud`, tus URLs serán:
```
https://res.cloudinary.com/democloud/...
```

---

## 2. Subir Videos a Cloudinary

### Opción A: Interface Web (Más fácil)

1. Ve a **Media Library** en el menú izquierdo
2. Haz clic en **Upload**
3. Selecciona o arrastra tus videos

**Videos a subir:**
- `hero-video.mp4` (video principal del hero)
- `boda-loop.mp4` (loop del proyecto boda)
- `dron-loop.mp4` (loop del proyecto dron)
- `fuesmen-loop.mp4` (loop del proyecto fuesmen)

4. **IMPORTANTE:** Organiza en una carpeta llamada `portfolio`
   - Crea una carpeta: Click en "New Folder" → `portfolio`
   - Sube los videos dentro de esta carpeta

### Opción B: CLI (Avanzado)

```bash
# Instalar Cloudinary CLI
npm install -g cloudinary-cli

# Configurar
cloudinary config

# Subir videos
cloudinary uploader upload hero-video.mp4 --public-id portfolio/hero-video
cloudinary uploader upload boda-loop.mp4 --public-id portfolio/boda-loop
cloudinary uploader upload dron-loop.mp4 --public-id portfolio/dron-loop
cloudinary uploader upload fuesmen-loop.mp4 --public-id portfolio/fuesmen-loop
```

### Verificar Public IDs

Después de subir, verifica los **Public IDs**:
- `portfolio/hero-video`
- `portfolio/boda-loop`
- `portfolio/dron-loop`
- `portfolio/fuesmen-loop`

---

## 3. Configurar el Portfolio

### Paso 1: Actualizar `index.html`

Abre `index.html` y busca la línea 81 (aproximadamente):

**BUSCAR:**
```html
src="https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/...
```

**REEMPLAZAR** `YOUR_CLOUD_NAME` con tu cloud name real en **TODAS** las URLs.

Ejemplo si tu cloud name es `democloud`:

```html
<!-- Antes -->
src="https://res.cloudinary.com/YOUR_CLOUD_NAME/video/upload/q_auto:good,f_webm,w_1920,h_1080,c_fill,g_auto/portfolio/hero-video.webm"

<!-- Después -->
src="https://res.cloudinary.com/democloud/video/upload/q_auto:good,f_webm,w_1920,h_1080,c_fill,g_auto/portfolio/hero-video.webm"
```

**Hay 5 URLs en total en el hero section:**
1. `poster` (línea ~81)
2. Desktop WebM (línea ~86)
3. Desktop MP4 (línea ~92)
4. Mobile WebM (línea ~98)
5. Mobile MP4 (línea ~104)

### Paso 2: Actualizar `js/projects-data.js`

Abre `js/projects-data.js` y en la línea 11:

**CAMBIAR:**
```javascript
const CLOUDINARY_CLOUD_NAME = 'YOUR_CLOUD_NAME'; // ⚠️ CAMBIAR ESTO
```

**A:**
```javascript
const CLOUDINARY_CLOUD_NAME = 'democloud'; // Tu cloud name real
```

Luego, verifica que los Public IDs coincidan con los que subiste:

```javascript
const projects = [
  {
    title: "Nadia & Nacho",
    cloudinaryId: "portfolio/boda-loop", // ✅ Verificar
    // ...
  },
  // ...
];
```

### Paso 3: Guardar y Probar

1. Guarda todos los archivos
2. Abre `index.html` en tu navegador
3. Verifica que los videos carguen

---

## 4. Testing

### Test 1: Desktop

1. Abre Chrome DevTools (F12)
2. Ve a la pestaña **Network**
3. Filtra por "video"
4. Refresca la página
5. Deberías ver que se cargan videos desde `res.cloudinary.com`

### Test 2: Mobile

1. En Chrome DevTools, presiona Ctrl+Shift+M (toggle device toolbar)
2. Selecciona "iPhone 12 Pro" o "Samsung Galaxy S20"
3. Refresca la página
4. Verifica:
   - ✅ El video se reproduce automáticamente
   - ✅ El video es más pequeño (versión mobile)
   - ✅ No se abre en pantalla completa

### Test 3: Diferentes Conexiones

1. En Chrome DevTools → Network tab
2. En "Throttling" selecciona "Fast 3G" o "Slow 3G"
3. Refresca la página
4. El video debería cargar sin problemas

---

## 5. Troubleshooting

### ❌ Error: "Failed to load resource: 404"

**Problema:** El video no existe en Cloudinary

**Solución:**
1. Verifica que el video esté subido:
   - Ve a Cloudinary Media Library
   - Busca el video
   - Verifica el Public ID
2. Asegúrate que el Public ID en tu código coincida **exactamente**
3. Ejemplo correcto: `portfolio/hero-video` (sin extensión)

---

### ❌ Error: "Access denied"

**Problema:** Tu Cloud Name es incorrecto o la cuenta está en modo privado

**Solución:**
1. Ve a Settings → Security
2. Verifica que **Resource list** esté en "Public"
3. Verifica tu Cloud Name en Dashboard

---

### ❌ El video tarda mucho en cargar

**Problema:** Video original muy pesado o transformaciones incorrectas

**Solución 1:** Optimizar antes de subir
```bash
# Comprimir video antes de subir
ffmpeg -i input.mp4 -c:v libx264 -crf 28 -preset slow output.mp4
```

**Solución 2:** Ajustar transformaciones
En tu código, cambia de `q_auto:good` a `q_auto:low`:
```javascript
q_auto:low,f_webm,w_1280,h_720
```

---

### ❌ El video no se reproduce en iPhone

**Problema:** Faltan atributos críticos

**Solución:** Verifica que tu `<video>` tenga:
```html
<video 
    autoplay 
    muted          <!-- ⚠️ OBLIGATORIO -->
    loop 
    playsinline    <!-- ⚠️ OBLIGATORIO para iOS -->
    preload="auto"
>
```

---

### ❌ Aparece el botón de play pero el video no funciona

**Problema:** JavaScript no se está ejecutando

**Solución:**
1. Abre Chrome DevTools → Console
2. Busca errores en rojo
3. Verifica que `js/hero.js` esté cargado
4. En el HTML, antes de `</body>`:
```html
<script src="js/hero.js"></script>
```

---

## 📊 Transformaciones de Cloudinary Explicadas

### Sintaxis Básica
```
https://res.cloudinary.com/CLOUD_NAME/video/upload/TRANSFORMATIONS/PUBLIC_ID
```

### Parámetros Principales

| Parámetro | Descripción | Ejemplo |
|-----------|-------------|---------|
| `q_auto` | Calidad automática | `q_auto:good`, `q_auto:low` |
| `f_auto` | Formato automático | `f_auto` (elige webm/mp4) |
| `w_` | Ancho | `w_1920` |
| `h_` | Alto | `h_1080` |
| `c_fill` | Crop para llenar | `c_fill` |
| `g_auto` | Gravedad automática | `g_auto` (centro inteligente) |

### Ejemplos Prácticos

**Desktop Alta Calidad:**
```
q_auto:good,f_webm,w_1920,h_1080,c_fill,g_auto/portfolio/hero-video
```

**Mobile Optimizado:**
```
q_auto:low,f_mp4,w_1280,h_720,c_fill,g_auto/portfolio/hero-video
```

**Poster/Thumbnail:**
```
so_0.0,q_auto,f_jpg,w_1920/portfolio/hero-video.jpg
```
(`so_0.0` = extraer frame en segundo 0)

---

## 🎯 Mejores Prácticas

### ✅ DO (Hacer):

1. **Organizar en carpetas:**
   ```
   portfolio/
   ├── hero-video
   ├── boda-loop
   ├── dron-loop
   └── fuesmen-loop
   ```

2. **Usar `q_auto` para calidad dinámica**
   - Cloudinary ajustará la calidad según la conexión

3. **Versiones Desktop y Mobile separadas**
   - Desktop: 1920x1080
   - Mobile: 1280x720

4. **Usar `f_auto` para formato automático**
   - Cloudinary servirá WebM a Chrome, MP4 a Safari, etc.

### ❌ DON'T (No hacer):

1. ❌ **No uses URLs absolutas locales**
   ```html
   <!-- MAL -->
   <source src="/assets/video.mp4">
   
   <!-- BIEN -->
   <source src="https://res.cloudinary.com/...">
   ```

2. ❌ **No subas videos sin comprimir**
   - Comprímelos primero con FFmpeg

3. ❌ **No uses la misma calidad para todo**
   - Desktop: `q_auto:good`
   - Mobile: `q_auto:low`

---

## 🚀 Deploy Checklist

Antes de subir a producción:

- [ ] Todos los videos subidos a Cloudinary
- [ ] Cloud Name actualizado en todos los archivos
- [ ] Public IDs verificados
- [ ] Videos funcionan en desktop
- [ ] Videos funcionan en mobile
- [ ] Videos funcionan en Safari/iOS
- [ ] Tiempos de carga < 3 segundos en 4G
- [ ] Botón de play aparece si autoplay falla
- [ ] Console sin errores (F12)

---

## 📞 Soporte Cloudinary

Si tienes problemas específicos con Cloudinary:

1. **Documentación oficial:** https://cloudinary.com/documentation/video_manipulation_and_delivery
2. **Support:** https://support.cloudinary.com
3. **Community:** https://community.cloudinary.com

---

## 🎉 ¡Listo!

Una vez configurado, tu portfolio:
- ✅ Cargará videos 80% más rápido
- ✅ Funcionará perfecto en mobile
- ✅ Servirá el formato óptimo automáticamente
- ✅ Ajustará calidad según la conexión
- ✅ Escalará a millones de visitas sin problemas

**Próximos pasos:**
1. Configurar CDN para assets estáticos
2. Implementar lazy loading de imágenes
3. Añadir más proyectos al portfolio
4. Optimizar SEO con meta tags
