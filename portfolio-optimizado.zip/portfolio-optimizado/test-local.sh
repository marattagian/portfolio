#!/bin/bash

# ========================================
# Script de Testing Local - Portfolio
# ========================================

echo "🧪 Portfolio Testing Script"
echo "============================"
echo ""

# Colores para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Verificar si estamos en el directorio correcto
if [ ! -f "index.html" ]; then
    echo -e "${RED}❌ Error: index.html not found${NC}"
    echo "Please run this script from your portfolio directory"
    exit 1
fi

echo -e "${GREEN}✅ Found portfolio files${NC}"
echo ""

# ========================================
# 1. Verificar archivos necesarios
# ========================================
echo "📁 Checking files..."

files=(
    "index.html"
    "css/main.css"
    "js/hero.js"
    "js/projects-data.js"
    "js/portfolio.js"
    "js/lightbox.js"
    "js/navigation.js"
    "js/contact.js"
)

missing_files=()

for file in "${files[@]}"; do
    if [ -f "$file" ]; then
        echo -e "  ${GREEN}✓${NC} $file"
    else
        echo -e "  ${RED}✗${NC} $file ${RED}(missing)${NC}"
        missing_files+=("$file")
    fi
done

if [ ${#missing_files[@]} -gt 0 ]; then
    echo ""
    echo -e "${RED}❌ Missing files detected${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}✅ All files present${NC}"
echo ""

# ========================================
# 2. Verificar configuración de Cloudinary
# ========================================
echo "☁️  Checking Cloudinary configuration..."

# Verificar en index.html
if grep -q "YOUR_CLOUD_NAME" index.html; then
    echo -e "  ${RED}✗${NC} index.html: Cloudinary not configured"
    echo -e "    ${YELLOW}⚠️  Replace YOUR_CLOUD_NAME with your actual cloud name${NC}"
    CLOUDINARY_CONFIGURED=false
else
    echo -e "  ${GREEN}✓${NC} index.html: Cloudinary configured"
    CLOUDINARY_CONFIGURED=true
fi

# Verificar en projects-data.js
if grep -q "YOUR_CLOUD_NAME" js/projects-data.js; then
    echo -e "  ${RED}✗${NC} projects-data.js: Cloudinary not configured"
    CLOUDINARY_CONFIGURED=false
else
    echo -e "  ${GREEN}✓${NC} projects-data.js: Cloudinary configured"
fi

echo ""

# ========================================
# 3. Verificar atributos críticos del video
# ========================================
echo "🎬 Checking video attributes..."

required_attrs=("muted" "playsinline" "autoplay" "loop")
missing_attrs=()

for attr in "${required_attrs[@]}"; do
    if grep -q "$attr" index.html; then
        echo -e "  ${GREEN}✓${NC} $attr attribute found"
    else
        echo -e "  ${RED}✗${NC} $attr attribute ${RED}missing${NC}"
        missing_attrs+=("$attr")
    fi
done

if [ ${#missing_attrs[@]} -gt 0 ]; then
    echo ""
    echo -e "${RED}❌ Missing critical video attributes${NC}"
    echo -e "${YELLOW}These are required for mobile playback!${NC}"
fi

echo ""

# ========================================
# 4. Iniciar servidor local
# ========================================
echo "🚀 Starting local server..."
echo ""

# Detectar qué servidor usar
if command -v python3 &> /dev/null; then
    SERVER_CMD="python3 -m http.server 8000"
    SERVER_TYPE="Python 3"
elif command -v python &> /dev/null; then
    SERVER_CMD="python -m SimpleHTTPServer 8000"
    SERVER_TYPE="Python 2"
elif command -v npx &> /dev/null; then
    SERVER_CMD="npx serve -p 8000"
    SERVER_TYPE="npx serve"
else
    echo -e "${RED}❌ No server available${NC}"
    echo "Please install Python or Node.js"
    exit 1
fi

echo "Using: $SERVER_TYPE"
echo ""
echo -e "${GREEN}✅ Server starting on http://localhost:8000${NC}"
echo ""

# Mostrar IP local
if command -v ipconfig &> /dev/null; then
    # Windows
    LOCAL_IP=$(ipconfig | grep -i "IPv4" | head -1 | awk '{print $NF}')
elif command -v ifconfig &> /dev/null; then
    # Mac/Linux
    LOCAL_IP=$(ifconfig | grep "inet " | grep -v 127.0.0.1 | head -1 | awk '{print $2}')
else
    LOCAL_IP="Unable to detect"
fi

echo "📱 For mobile testing, open on your phone:"
echo -e "${YELLOW}http://$LOCAL_IP:8000${NC}"
echo ""

# ========================================
# 5. Checklist de Testing
# ========================================
echo "📋 Testing Checklist:"
echo "====================="
echo ""
echo "Desktop:"
echo "  [ ] Hero video plays automatically"
echo "  [ ] Video loops correctly"
echo "  [ ] Project cards load"
echo "  [ ] Hover effects work"
echo "  [ ] Navigation works"
echo "  [ ] Contact form works"
echo ""
echo "Mobile (test on real device):"
echo "  [ ] Hero video plays on mobile"
echo "  [ ] Video doesn't go fullscreen"
echo "  [ ] Burger menu works"
echo "  [ ] Touch interactions work"
echo "  [ ] Videos load fast (<3s on 4G)"
echo ""

if [ "$CLOUDINARY_CONFIGURED" = false ]; then
    echo -e "${YELLOW}⚠️  WARNING: Cloudinary not configured${NC}"
    echo "Videos may not load until you configure Cloudinary"
    echo "See CLOUDINARY-SETUP.md for instructions"
    echo ""
fi

echo "Press Ctrl+C to stop the server"
echo "=========================================="
echo ""

# Iniciar servidor
eval $SERVER_CMD
